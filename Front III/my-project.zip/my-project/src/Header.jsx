const Header =()=>{
    return (
        <header className="header">
            <nav className="header_nav">
                <ul className="header_ul">
                    <li className="header_li" >Home</li>
                    <li className="header_li">About</li>
                    <li className="header_li">experience</li>
                    <li className="header_li">Movies</li>
                </ul>
            </nav>
        </header>
    )
};
  
  export default Header;