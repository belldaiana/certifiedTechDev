const PersonalInformation = ({ name, lastName, nationality, age, avatar }) => {
    return (
      <main className='main'>
        <section>
          <h1>Personal Information:</h1>
          <p>Name: {name}</p>
          <p>Last Name: {lastName}</p>
          <p>Age: {age} years old</p>
          <p>Nationality: {nationality}</p>
        </section>
        <section>
          <img className='imagen' src={avatar} alt='profile' />
        </section>
      </main>
    );
  };
  
  export default PersonalInformation;