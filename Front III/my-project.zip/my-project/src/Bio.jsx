const Bio = ({ bio }) => {
  return (
      <p>{bio}</p>
  )
}

export default Bio;