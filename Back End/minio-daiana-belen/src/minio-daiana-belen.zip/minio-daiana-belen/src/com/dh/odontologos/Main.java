package com.dh.odontologos;

import com.dh.odontologos.dao.imp.OdontologoDaoH2;
import com.dh.odontologos.model.Odontologo;
import com.dh.odontologos.service.OdontologoService;

public class Main {
    public static void main(String[] args) {


    }
}
