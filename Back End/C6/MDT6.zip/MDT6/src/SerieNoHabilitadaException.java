public class SerieNoHabilitadaException extends Throwable {
    public SerieNoHabilitadaException(){
        super();
    }
    public SerieNoHabilitadaException(String mensaje){
        super(mensaje);
    }
}
