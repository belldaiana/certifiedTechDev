public interface ISerie {
    public String getSerie(String serie) throws SerieNoHabilitadaException;
}
